package modi;

public enum RelativePosition {
	INCLUDING,
	INCLUDED,
	OVERLAP,
	ADJACENT,
	SEPERATED
}
