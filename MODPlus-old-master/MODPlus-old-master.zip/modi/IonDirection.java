package modi;

public enum IonDirection {
	Y_DIRECTION,
	B_DIRECTION,
}
