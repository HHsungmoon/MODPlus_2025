package modi;

public enum PTMPosition {
	NOT_DEFINED,
	ANYWHERE,
	ANY_N_TERM,
	ANY_C_TERM,
	PROTEIN_N_TERM,
	PROTEIN_C_TERM,
	
	PTMPOSITION_COUNT		// to count enum values

}

